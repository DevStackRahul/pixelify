

<?php $__env->startSection('content'); ?>

<!-- Facebook Pixel Code -->
<script>
    !function(f,b,e,v,n,t,s)
    {if(f.fbq)return;n=f.fbq=function(){n.callMethod?
    n.callMethod.apply(n,arguments):n.queue.push(arguments)};
    if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
    n.queue=[];t=b.createElement(e);t.async=!0;
    t.src=v;s=b.getElementsByTagName(e)[0];
    s.parentNode.insertBefore(t,s)}(window, document,'script',
    'https://connect.facebook.net/en_US/fbevents.js');
    fbq('init', '490714432403594
    fbq('track', 'PageView');
  
  
</script>
<noscript>
  <img height="1" width="1" id="testing"src="https://www.facebook.com/tr?id=490714432403594=1"/>
</noscript>

<?php 

 $ch = curl_init('https://graph.facebook.com/490714432403594?access_token=EAAGZBTVttZBIoBAFEk8xGtLmpEPJKVLkBYcYC4VyQIeXXCAolQhDID74MN0DmVZBZCPZBqiDYHyUBDnkKlKMnu2kbfpbFlJSPFHaZCKpPI8CiUasA0hoJ3s91SfmBVev4scZAx8HrSixrYgFlxsUjJUIkjLJQdgbaRDOCeNdh35ZCNTDUL6hxWn75XA4rEgE5woZD');
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
        $response = curl_exec($ch);
        var_dump($response);
        var_dump(json_decode($response)); 

?>
<!-- End Facebook Pixel Code -->


    <!-- You are: (shop domain name) -->
    <p> You are: <?php echo e($shopDomain ?? Auth::user()->name); ?> </p>
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
    
    <div class="page-block">
	<div class="container">
		<div class="page-grid">
			<div class="page-list">
				<div class="social-media">
					<div class="social-media-img">
						<img src="images/Facebook_Logo.png">
					</div>
					<div class="media-title">
						<h2>Facebook Pixel</h2>
					</div>	
				</div>
				<div class="rate-list">
					<div class="rate-title">
						<h4>Today Revenue</h4>
						<h1>$64.264</h1>
					</div>
					<div class="popup_main">
					  <button class="open_popup">Manage</button>
					  <div class="popup_body">
						<div class="popup_back"></div>
						  <div class="popup_contain">
							<div class="popup_close">x</div>
								<div class="popup_form">
									<form>
										<label for="fname">Add Pixel</label>
											<div class="popup-text">
											  <input type="text" id="fname" name="fname" value="">
											  <button><img src="images/delete_icon.png"></button>
											</div>
											<div class="popup_btn">										  
											  <input type="Submit" value="Add">
											</div>
									</form> 
								</div>	
						  </div>
					  </div>
					</div>
				</div>		
			</div>
			<div class="page-list">
				<div class="social-media">
					<div class="social-media-img">
						<img src="images/TikTok-Logo.png">
					</div>
					<div class="media-title">
						<h2>Tiktok Pixel</h2>
					</div>	
				</div>
				<div class="rate-list">
					<div class="rate-title">
						<h4>Today Revenue</h4>
						<h1>$12.264</h1>
					</div>
					<div class="popup_main">
					  <button class="open_popup">Manage</button>
					  <div class="popup_body">
						<div class="popup_back"></div>
						  <div class="popup_contain">
							<div class="popup_close">x</div>
								<div class="popup_form">
									<form>
										<label for="fname">Add Pixel</label>
											<div class="popup-text">
											  <input type="text" id="fname" name="fname" value="">
											  <button><img src="images/delete_icon.png"></button>
											</div>
											<div class="popup_btn">										  
											  <input type="Submit" value="Add">
											</div>
									</form> 
								</div>	
						  </div>
					  </div>
					</div>
				</div>		
			</div>
			<div class="page-list">
				<div class="social-media">
					<div class="social-media-img">
						<img src="images/google-new.jpg">
					</div>
					<div class="media-title">
						<h2>Google Pixel</h2>
					</div>	
				</div>
				<div class="rate-list">
					<div class="rate-title">
						<h4>Today Revenue</h4>
						<h1>$654</h1>
					</div>
					<div class="popup_main">
					  <button class="open_popup">Manage</button>
					  <div class="popup_body">
						<div class="popup_back"></div>
						  <div class="popup_contain">
							<div class="popup_close">x</div>
								<div class="popup_form">
									<form>
										<label for="fname">Add Pixel</label>
											<div class="popup-text">
											  <input type="text" id="fname" name="fname" value="">
											  <button><img src="images/delete_icon.png"></button>
											</div>
											<div class="popup_btn">										  
											  <input type="Submit" value="Add">
											</div>
									</form> 
								</div>	
						  </div>
					  </div>
					</div>
				</div>		
			</div>
			<div class="page-list">
				<div class="social-media">
					<div class="social-media-img">
						<img src="images/pinterest.png">
					</div>
					<div class="media-title">
						<h2>Pinterest Pixel</h2>
					</div>	
				</div>
				<div class="rate-list">
					<div class="rate-title">
						<h4>Today Revenue</h4>
						<h1>$12.264</h1>
					</div>
					<div class="popup_main">
					  <button class="open_popup">Manage</button>
					  <div class="popup_body">
						<div class="popup_back"></div>
						  <div class="popup_contain">
							<div class="popup_close">x</div>
								<div class="popup_form">
									<form>
										<label for="fname">Add Pixel</label>
											<div class="popup-text">
											  <input type="text" id="fname" name="fname" value="">
											  <button><img src="images/delete_icon.png"></button>
											</div>
											<div class="popup_btn">										  
											  <input type="Submit" value="Add">
											</div>
									</form> 
								</div>	
						  </div>
					  </div>
					</div>
				</div>		
			</div>
			<div class="page-list">
				<div class="social-media">
					<div class="social-media-img">
						<img src="images/snapchat-new.png">
					</div>
					<div class="media-title">
						<h2>Snapchat Pixel</h2>
					</div>	
				</div>
				<div class="rate-list">
					<div class="rate-title">
						<h4>Today Revenue</h4>
						<h1>$14.264</h1>
					</div>
					<div class="popup_main">
					  <button class="open_popup">Manage</button>
					  <div class="popup_body">
						<div class="popup_back"></div>
						  <div class="popup_contain">
							<div class="popup_close">x</div>
								<div class="popup_form">
									<form>
										<label for="fname">Add Pixel</label>
											<div class="popup-text">
											  <input type="text" id="fname" name="fname" value="">
											  <button><img src="images/delete_icon.png"></button>
											</div>
											<div class="popup_btn">										  
											  <input type="Submit" value="Add">
											</div>
									</form> 
								</div>	
						  </div>
					  </div>
					</div>
				</div>		
			</div>
			<div class="page-list">
				<div class="social-media">
					<div class="social-media-img">
						<img src="images/bing.png">
					</div>
					<div class="media-title">
						<h2>Bing Pixel</h2>
					</div>	
				</div>
				<div class="rate-list">
					<div class="rate-title">
						<h4>Today Revenue</h4>
						<h1>$12.264</h1>
					</div>
					<div class="popup_main">
					  <button class="open_popup">Manage</button>
					  <div class="popup_body">
						<div class="popup_back"></div>
						  <div class="popup_contain">
							<div class="popup_close">x</div>
								<div class="popup_form">
									<form>
										<label for="fname">Add Pixel</label>
											<div class="popup-text">
											  <input type="text" id="fname" name="fname" value="">
											  <button><img src="images/delete_icon.png"></button>
											</div>
											<div class="popup_btn">										  
											  <input type="Submit" value="Add">
											</div>
									</form> 
								</div>	
						  </div>
					  </div>
					</div>
				</div>		
			</div>
		</div>
	</div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <?php echo \Illuminate\View\Factory::parentPlaceholder('scripts'); ?>
    <script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
    
    <script>
        actions.TitleBar.create(app, { title: 'Welcome' });
    </script>
    <script>
 $(".open_popup").click(function () {
   $(this).parent(".popup_main").children(".popup_body").addClass("popup_body_show");
   });
 $(".popup_close").click(function () {
   $(".popup_body").removeClass("popup_body_show");
   });
 $(".popup_back").click(function () {
   $(".popup_body").removeClass("popup_body_show");
   });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('shopify-app::layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/digidcor/public_html/socialpixelify.auspicioussoft.com/resources/views/welcome.blade.php ENDPATH**/ ?>