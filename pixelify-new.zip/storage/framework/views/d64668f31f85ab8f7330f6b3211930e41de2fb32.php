<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <base target="_top">

        <title>Redirecting...</title>

        <script type="text/javascript">window.top.location.href = "<?php echo $url; ?>";</script>
    </head>
    <body>
    </body>
</html>
<?php /**PATH /home2/digidcor/public_html/socialpixelify.auspicioussoft.com/vendor/osiset/laravel-shopify/src/resources/views/billing/fullpage_redirect.blade.php ENDPATH**/ ?>